#ifndef RTW_VERSION_H
	#define RTW_VERSION_H
	#define RTW_VERSION "rtw_android14_20231130"
#endif /* RTW_VERSION_H */
